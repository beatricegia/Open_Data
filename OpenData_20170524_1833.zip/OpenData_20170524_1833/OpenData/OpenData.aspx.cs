﻿using System;
using System.Data;
using System.Data.OleDb;
using System.Web.UI;

namespace OpenData
{
    public partial class OpenData : System.Web.UI.Page
    {

        // impostazioni dati ruolo
        // anno ruolo
        int anno_emissione = 2017;
        // emissione ruolo catasto (Fabbricati e Terreni)
        int num_emissione_catasto = 1;
        // emissione ruolo complessivo
        int num_emissione_ruolo_complessivo = 50;

        // impostazioni connessione DB

        //string istanza = @"BEATRICE-PC\SQLEXPRESS";
        //string database = "OpenData_ConsROM";
        //string user_id = "sa";
        //string password = "b4525vyi";

        string istanza = "db01";
        string database = "Cons17_ConsROM";
        string user_id = "opendata";
        string password = "ovrMV5yzrZmLU9bCJrc8";

        string connection_string = "";

        public OpenData()
        {
            connection_string = @"Provider=sqloledb;" +
                    @"Data source=" + istanza + ";" + @"Initial Catalog=" + database + ";" +
                    @"User Id=" + user_id + ";" + @"Password=" + password + ";";

        }
        
        protected void btnVisualizza_Click(object sender, EventArgs e)
        {

            string query = "";

            switch (ddlEstrazioni.SelectedValue.ToUpper())
            {

                #region open data contribuenti
                case "NUMERO DI CONTRIBUENTI PER COMUNE":

                    query = "";
                    query += "SELECT ";
                    query += "   Comune AS Com, TABE.des AS Comune, COUNT( DISTINCT CodiceFiscale) AS Num_Contribuenti ";
                    query += "FROM ";
                    query += "   ElementiConsortili INNER JOIN TABE ON ElementiConsortili.Comune = TABE.cod ";
                    query += "WHERE 1=1 ";
                    query += "  AND TABE.cta='COM' ";
                    query += "  AND AnnoEmissione = " + anno_emissione + " ";
                    query += "  AND NumEmissione = " + num_emissione_catasto + " ";
                    query += "  AND TABE.cod != '**********' ";
                    query += "GROUP BY ";
                    query += "   Comune, TABE.des ";
                    query += "ORDER BY ";
                    query += "   TABE.des";
                    break;

                case "NUMERO DI CONTRIBUENTI PER COMUNE UOMO O DONNA":

                    query += "SELECT ";
                    query += "	 Comune AS Com, TABE.des AS Comune, ";
                    query += "	 SUM(CASE WHEN Anagrafiche.Sesso='F' THEN 1 ELSE 0 END) as Femmine, ";
                    query += "	 SUM(CASE WHEN Anagrafiche.Sesso='M' THEN 1 ELSE 0 END) as Maschi, ";
                    query += "	 SUM(CASE WHEN Anagrafiche.Sesso='S' THEN 1 ELSE 0 END) as Societa, ";
                    query += "	 SUM(CASE WHEN Anagrafiche.Sesso NOT IN ('F','M','S') THEN 1 ELSE 0 END) as Altro ";
                    query += "FROM  ";
                    query += "	 ElementiConsortili INNER JOIN TABE ON ElementiConsortili.Comune = TABE.cod ";
                    query += "	 INNER JOIN (SELECT CodiceFiscale, MIN(Sesso) as Sesso FROM Anagrafiche GROUP BY CodiceFiscale) Anagrafiche ON ";
                    query += "		ElementiConsortili.CodiceFiscale = Anagrafiche.CodiceFiscale ";
                    query += "WHERE 1=1 ";
                    query += "   AND AnnoEmissione = " + anno_emissione + " ";
                    query += "   AND NumEmissione = " + num_emissione_catasto + " ";
                    query += "  AND TABE.cta='COM' ";
                    query += "  AND TABE.cod != '**********' ";
                    query += "GROUP BY  ";
                    query += "	 Comune, TABE.des ";
                    query += "ORDER BY ";
                    query += "   TABE.des";
                    break;

                case "DETTAGLIO CONTRIBUENTE UTENTE DI ACCESSO":

                    query += "SELECT ";
                    query += "	 CodAnagrafica, Cognome, Nome, Sesso ";
                    query += "FROM  ";
                    query += "	 Anagrafiche ";
                    query += "WHERE 1=1 ";
                    query += "   AND CodiceFiscale = '" + Session["codice_fiscale_accesso"] + "' ";
                    break;
                #endregion
                #region open data terreni

                case "NUMERO DI TERRENI PER COMUNE":
                    query = "";
                    query += "SELECT ";
                    query += "   Comune AS Com, TABE.des AS Comune, COUNT( DISTINCT CodiceFiscale) AS Num_Terreni ";
                    query += "FROM ";
                    query += "   ElementiConsortili INNER JOIN TABE ON ElementiConsortili.Comune = TABE.cod ";
                    query += "WHERE ";
                    query += "   FOT = 'T' ";
                    query += "   AND AnnoEmissione = " + anno_emissione + " ";
                    query += "   AND NumEmissione = " + num_emissione_catasto + " ";
                    query += "  AND TABE.cta='COM' ";
                    query += "  AND TABE.cod != '**********' ";
                    query += "GROUP BY  ";
                    query += "	 Comune, TABE.des ";
                    query += "ORDER BY ";
                    query += "   TABE.des";
                    break;

                case "NUMERO DI TERRENI PIÙ GRANDI DI 10000 METRI QUADRATI":
                    query = "";
                    query += "SELECT ";
                    query += "   Comune AS Com, TABE.des AS Comune, COUNT( DISTINCT CodiceFiscale) AS Num_Terreni ";
                    query += "FROM ";
                    query += "   ElementiConsortili INNER JOIN TABE ON ElementiConsortili.Comune = TABE.cod ";
                    query += "WHERE ";
                    query += "   FOT = 'T' AND Superf > 10000 ";
                    query += "   AND AnnoEmissione = " + anno_emissione + " ";
                    query += "   AND NumEmissione = " + num_emissione_catasto + " ";
                    query += "  AND TABE.cta='COM' ";
                    query += "  AND TABE.cod != '**********' ";
                    query += "GROUP BY ";
                    query += "   Comune, TABE.des ";
                    query += "ORDER BY ";
                    query += "   TABE.des";
                    break;

                case "NUMERO DI TERRENI PIÙ GRANDI DI 100000 METRI QUADRATI":
                    query = "";
                    query += "SELECT ";
                    query += "   Comune AS Com, TABE.des AS Comune, COUNT( DISTINCT CodiceFiscale) AS Num_Terreni ";
                    query += "FROM ";
                    query += "   ElementiConsortili INNER JOIN TABE ON ElementiConsortili.Comune = TABE.cod ";
                    query += "WHERE ";
                    query += "   FOT = 'T' AND Superf > 100000 ";
                    query += "   AND AnnoEmissione = " + anno_emissione + " ";
                    query += "   AND NumEmissione = " + num_emissione_catasto + " ";
                    query += "  AND TABE.cta='COM' ";
                    query += "  AND TABE.cod != '**********' ";
                    query += "GROUP BY ";
                    query += "   Comune, TABE.des ";
                    query += "ORDER BY ";
                    query += "   TABE.des";
                    break;

                case "SUPERFICIE MEDIA TERRENI PER COMUNE":
                    query = "";
                    query += "SELECT ";
                    query += "   Comune AS Com, TABE.des AS Comune, AVG(Superf) AS Superficie_Media ";
                    query += "FROM ";
                    query += "   ElementiConsortili INNER JOIN TABE ON ElementiConsortili.Comune = TABE.cod ";
                    query += "WHERE ";
                    query += "   FOT = 'T' ";
                    query += "   AND AnnoEmissione = " + anno_emissione + " ";
                    query += "   AND NumEmissione = " + num_emissione_catasto + " ";
                    query += "  AND TABE.cta='COM' ";
                    query += "  AND TABE.cod != '**********' ";
                    query += "GROUP BY ";
                    query += "   Comune, TABE.des ";
                    query += "ORDER BY ";
                    query += "   TABE.des";
                    break;

                case "TERRENI UTENTE DI ACCESSO":
                    query = "";
                    query += "SELECT ";
                    query += "   Comune AS Com, TABE.des AS Comune, CDitta, Foglio, Numero, AnnoEmissione, AnnoCompetenza, Superf, RuoloCER ";
                    query += "FROM ";
                    query += "   ElementiConsortili INNER JOIN TABE ON ElementiConsortili.Comune = TABE.cod ";
                    query += "WHERE ";
                    query += "   FOT = 'T' ";
                    query += "   AND AnnoEmissione = " + anno_emissione + " ";
                    query += "   AND NumEmissione = " + num_emissione_catasto + " ";
                    query += "   AND CodiceFiscale = '" + Session["codice_fiscale_accesso"] + "' ";
                    query += "   AND TABE.cta='COM' ";
                    query += "   AND TABE.cod != '**********' ";
                    query += "GROUP BY ";
                    query += "   Comune, TABE.des ";
                    query += "ORDER BY ";
                    query += "   Comune, sezCat, Foglio, Numero, Sub, TABE.des ";
                    break;
                #endregion

                #region open data fabbricati
                case "NUMERO DI FABBRICATI PER COMUNE":
                    query = "";
                    query += "SELECT ";
                    query += "   Comune AS Com, TABE.des AS Comune, COUNT( DISTINCT CodiceFiscale) AS Num_Fabbricati ";
                    query += "FROM ";
                    query += "   ElementiConsortili INNER JOIN TABE ON ElementiConsortili.Comune = TABE.cod ";
                    query += "WHERE ";
                    query += "   FOT LIKE 'F' ";
                    query += "   AND AnnoEmissione = " + anno_emissione + " ";
                    query += "   AND NumEmissione = " + num_emissione_catasto + " ";
                    query += "  AND TABE.cta='COM' ";
                    query += "  AND TABE.cod != '**********' ";
                    query += "GROUP BY ";
                    query += "   Comune, TABE.des ";
                    query += "ORDER BY ";
                    query += "   TABE.des";
                    break;

                case "FABBRICATI UTENTE DI ACCESSO":
                    query = "";
                    query += "SELECT ";
                    query += "   * ";
                    query += "FROM ";
                    query += "   ElementiConsortili ";
                    query += "WHERE ";
                    query += "   FOT = 'F' ";
                    query += "   AND AnnoEmissione = " + anno_emissione + " ";
                    query += "   AND NumEmissione = " + num_emissione_catasto + " ";
                    query += "   AND CodiceFiscale = '" + Session["codice_fiscale_accesso"] + "' ";
                    query += "ORDER BY ";
                    query += "   Comune, sezCat, Foglio, Numero, Sub ";
                    break;

                #endregion

                #region open data irrigazioni
                case "IRRIGAZIONI PER COMUNE":
                    query = "";
                    query += "SELECT ";
                    query += "   Comune AS Com, TABE.des AS Comune, AVG(Superf) AS Superficie_Media ";
                    query += "FROM ";
                    query += "   ElementiConsortili INNER JOIN TABE ON ElementiConsortili.Comune = TABE.cod ";
                    query += "WHERE ";
                    query += "   FOT = 'I' ";
                    query += "   AND AnnoEmissione = " + anno_emissione + " ";
                    query += "   AND NumEmissione = " + num_emissione_catasto + " ";
                    query += "  AND TABE.cta='COM' ";
                    query += "  AND TABE.cod != '**********' ";
                    query += "GROUP BY ";
                    query += "   Comune, TABE.des ";
                    query += "ORDER BY ";
                    query += "   TABE.des";
                    break;

                case "IRRIGAZIONI UTENTE DI ACCESSO":
                    query = "";
                    query += "SELECT ";
                    query += "   * ";
                    query += "FROM ";
                    query += "   ElementiConsortili ";
                    query += "WHERE ";
                    query += "   FOT = 'I' ";
                    query += "   AND AnnoEmissione = " + anno_emissione + " ";
                    query += "   AND NumEmissione = " + num_emissione_catasto + " ";
                    query += "   AND CodiceFiscale = '" + Session["codice_fiscale_accesso"] + "' ";
                    query += "ORDER BY ";
                    query += "   Comune ";
                    break;
                #endregion
                #region open data contribuzione
                case "MEDIA DI CONTRIBUZIONE PER COMUNE":
                    query = "";
                    query += "SELECT ";
                    query += "   Comune AS Com, TABE.des AS Comune, AVG(Imposta) AS Contribuzione_Media ";
                    query += "FROM ";
                    query += "   ElementiConsortili INNER JOIN TABE ON ElementiConsortili.Comune = TABE.cod ";
                    query += "WHERE 1=1 ";
                    query += "   AND AnnoEmissione = " + anno_emissione + " ";
                    query += "   AND NumEmissione = " + num_emissione_catasto + " ";
                    query += "  AND TABE.cta='COM' ";
                    query += "  AND TABE.cod != '**********' ";
                    query += "GROUP BY ";
                    query += "   Comune, TABE.des ";
                    query += "ORDER BY ";
                    query += "   TABE.des";
                    break;

                case "CONTRIBUZIONE UTENTE DI ACCESSO":
                    query = "";
                    query += "SELECT ";
                    query += "   * ";
                    query += "FROM ";
                    query += "   ElementiConsortili ";
                    query += "WHERE 1=1 ";
                    query += "   AND AnnoEmissione = " + anno_emissione + " ";
                    query += "   AND NumEmissione = " + num_emissione_catasto + " ";
                    query += "   AND CodiceFiscale = '" + Session["codice_fiscale_accesso"] + "' ";
                    query += "ORDER BY ";
                    query += "   Comune ";
                    break;
                    #endregion
            }

            try
            {
                OleDbConnection cnn = new OleDbConnection();
                cnn.ConnectionString = connection_string;

                cnn.Open();

                DataTable dt = new DataTable();
                OleDbDataAdapter adapter = new OleDbDataAdapter(query, cnn);

                adapter.Fill(dt);

                grdRisultati.DataSource = dt;
                grdRisultati.DataBind();
            }
            catch (Exception exc)
            {
                string script = "alert('" + exc.Message.Replace("'", "-") + "')";
                ScriptManager.RegisterStartupScript(this, GetType(), "alert", script, true);

                grdRisultati.DataSource = null;
                grdRisultati.DataBind();
            }
        }


        protected void btnLogin_Click(object sender, EventArgs e)
        {

            string query = "";

            // verifica negli avvisi dei ruoli di quella emissione
            query = "";
            query += "SELECT ";
            query += "   Imposta, Ruoli_N2.Cognome, Ruoli_N2.Nome, Ruoli_N2.DescrizioneSocieta ";
            query += "FROM ";
            query += "   Ruoli_N4 ";
            query += "   INNER JOIN Ruoli_N2 ON ";
            query += "      Ruoli_N4.AnnoEmissione = Ruoli_N2.AnnoEmissione ";
            query += "      AND Ruoli_N4.NumEmissione = Ruoli_N2.NumEmissione ";
            query += "      AND Ruoli_N4.CodicePartita = Ruoli_N2.CodicePartita ";
            query += "WHERE 1=1 ";
            query += "   AND Ruoli_N4.AnnoEmissione = " + anno_emissione + " ";
            query += "   AND Ruoli_N4.NumEmissione = " + num_emissione_ruolo_complessivo + " ";
            // verifica l'avviso rispetto al codice fiscale
            query += "   AND Ruoli_N2.CodiceFiscale = '" + txtCodiceFiscale.Text + "' ";

            try
            {
                OleDbConnection cnn = new OleDbConnection();
                cnn.ConnectionString = connection_string;

                cnn.Open();

                DataTable dt = new DataTable();
                OleDbDataAdapter adapter = new OleDbDataAdapter(query, cnn);

                adapter.Fill(dt);

                if (dt.Rows.Count>0)
                {
                    // verifica l'importo nell'intorno di 5 euro

                    double delta = Math.Abs(Convert.ToDouble(dt.Rows[0]["Imposta"].ToString()) - Convert.ToDouble(txtImportoAvviso.Text));

                    if (delta<=5)
                    {
                        lblInformazioni.Text = "Salve " +
                            dt.Rows[0]["Nome"].ToString() + " " + dt.Rows[0]["Cognome"].ToString() + dt.Rows[0]["DescrizioneSocieta"].ToString();
                        Session["codice_fiscale_accesso"] = txtCodiceFiscale.Text;

                        // ricalcola il combo contribuente con l'accesso autenticato
                        btnContribuenti_Click(null,null);
                    }
                }

                else
                {
                    Session["codice_fiscale_accesso"] = "";
                    lblInformazioni.Text = "Accesso anonimo";
                }
            }
            catch (Exception exc)
            {
                string script = "alert('" + exc.Message.Replace("'", "-") + "')";
                ScriptManager.RegisterStartupScript(this, GetType(), "alert", script, true);

                grdRisultati.DataSource = null;
                grdRisultati.DataBind();
            }

        }

        protected void btnContribuenti_Click(object sender, EventArgs e)
        {
            ddlEstrazioni.Items.Clear();
            ddlEstrazioni.Items.Add("Numero di contribuenti per comune");
            ddlEstrazioni.Items.Add("Numero di Contribuenti per comune uomo o donna");
            if (Session["codice_fiscale_accesso"].ToString().Length > 0)
                ddlEstrazioni.Items.Add("Dettaglio contribuente utente di accesso");

        }

        protected void btnTerreni_Click(object sender, EventArgs e)
        {
            ddlEstrazioni.Items.Clear();
            ddlEstrazioni.Items.Add("Numero di Terreni per comune");
            ddlEstrazioni.Items.Add("Numero di terreni più grandi di 10000 metri quadrati");
            ddlEstrazioni.Items.Add("Numero di terreni più grandi di 100000 metri quadrati");
            ddlEstrazioni.Items.Add("Superficie media terreni per comune");
            if (Session["codice_fiscale_accesso"].ToString().Length > 0)
                ddlEstrazioni.Items.Add("Terreni utente di accesso");
        }

        protected void btnFabbricati_Click(object sender, EventArgs e)
        {
            ddlEstrazioni.Items.Clear();
            ddlEstrazioni.Items.Add("Numero di Fabbricati per comune");
            if (Session["codice_fiscale_accesso"].ToString().Length > 0)
                ddlEstrazioni.Items.Add("Fabbricati utente di accesso");
        }

        protected void btnIrrigazioni_Click(object sender, EventArgs e)
        {
            ddlEstrazioni.Items.Clear();
            ddlEstrazioni.Items.Add("Irrigazioni per comune");
            if (Session["codice_fiscale_accesso"].ToString().Length > 0)
                ddlEstrazioni.Items.Add("Irrigazioni utente di accesso");
        }

        protected void btnContribuzione_Click(object sender, EventArgs e)
        {
            ddlEstrazioni.Items.Clear();
            ddlEstrazioni.Items.Add("Media di contribuzione per comune");
            if (Session["codice_fiscale_accesso"].ToString().Length > 0)
                ddlEstrazioni.Items.Add("Contribuzione utente di accesso");
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
                Session["codice_fiscale_accesso"] = "";
        }
    }
}