﻿using System;
using System.Data;
using System.Data.OleDb;
using System.Web.UI;

namespace OpenData
{
    public partial class OpenData : System.Web.UI.Page
    {

        // impostazioni connessione DB

        //// Filippo
        //string istanza = "falbertini";
        //string database = "Cons17_ConsFER_Export";
        //string user_id = "sa";
        //string password = "....";

        // Beatrice
        string istanza = @"BEATRICE-PC\SQLEXPRESS";
        string database = "OpenData_ConsROM";
        string user_id = "sa";
        string password = "b4525vyi";

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        //con il seguente metodo gestisco l'evento alla pressione del bottone Invio
        protected void btnVisualizza_Click(object sender, EventArgs e)
        {

            string query = "";

            switch (ddlEstrazione.SelectedValue.ToUpper())
            {
                case "NUMERO DI CONTRIBUENTI PER COMUNE":

                    query = "";
                    query += "SELECT ";
                    query += "   Comune AS Comune, COUNT( DISTINCT CodiceFiscale) AS Num_Contribuenti ";
                    query += "FROM ";
                    query += "   ElementiConsortili ";
                    query += "GROUP BY ";
                    query += "   Comune ";
                    break;

                case "NUMERO DI CONTRIBUENTI PER COMUNE UOMO O DONNA":

                    query += "SELECT ";
                    query += "	 Comune, ";
                    query += "	 SUM(CASE WHEN Anagrafiche.Sesso='F' THEN 1 ELSE 0 END) as Femmine, ";
                    query += "	 SUM(CASE WHEN Anagrafiche.Sesso='M' THEN 1 ELSE 0 END) as Maschi, ";
                    query += "	 SUM(CASE WHEN Anagrafiche.Sesso='S' THEN 1 ELSE 0 END) as Societa, ";
                    query += "	 SUM(CASE WHEN Anagrafiche.Sesso NOT IN ('F','M','S') THEN 1 ELSE 0 END) as Altro ";
                    query += "FROM  ";
                    query += "	 ElementiConsortili ";
                    query += "	 inner join (SELECT CodiceFiscale, MIN(Sesso) as Sesso FROM Anagrafiche GROUP BY CodiceFiscale) Anagrafiche ON ";
                    query += "		ElementiConsortili.CodiceFiscale = Anagrafiche.CodiceFiscale ";
                    query += "GROUP BY  ";
                    query += "	 Comune ";
                    break;

                case "NUMERO DI FABBRICATI PER COMUNE":
                    break;

                case "NUMERO DI TERRENI PER COMUNE":
                    break;

                case "NUMERO DI TERRENI PIÙ GRANDI DI TOT":
                    break;

                case "MEDIA DI CONTRIBUZIONE PER COMUNE":
                    break;

               case "TERRENI SUPERFICIE MEDIA PER CF":
                    break;
            }

            try
            {
                OleDbConnection cnn = new OleDbConnection();
                cnn.ConnectionString = @"Provider=sqloledb;" +
                    @"Data source=" + istanza + ";" + @"Initial Catalog=" + database + ";" +
                    @"User Id=" + user_id + ";" + @"Password=" + password + ";";

                cnn.Open();

                DataTable table = new DataTable();
                OleDbDataAdapter adapter = new OleDbDataAdapter(query, cnn);

                adapter.Fill(table);

                grdRisultati.DataSource = table;
                grdRisultati.DataBind();
            }
            catch (Exception exc)
            {
                string script = "alert('" + exc.Message.Replace("'","-") + "')";
                ScriptManager.RegisterStartupScript(this, GetType(), "alert", script, true);

                grdRisultati.DataSource = null;
                grdRisultati.DataBind();
            }
        }
    }
}