﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ProgettoCBR1.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }
    }
}



/* INSERIMENTO DATABASE
<configuration> 
<connectionStrings> 
<add name="TEST" 
connectionString= "server=(local);
integrated security=sspi;database= OpenData_ConsROM "/> 
</connectionStrings>
</configuration>
*/
